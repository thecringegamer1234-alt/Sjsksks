package com.aerocompanion.overlay

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.sin

/**
 * Small, completely blue, 6-joint Frutiger Aero bubble-person renderer.
 * 6 articulated joints: torso(waist), head(neck), leftArm, rightArm, leftLeg, rightLeg.
 */
class AeroOverlayRenderer(private val context: Context) : GLSurfaceView.Renderer {
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private var startNs = System.nanoTime()

    // Small completely-blue bubble palette (RGBA)
    private val bubbleOuterBlue = floatArrayOf(0.22f, 0.74f, 0.97f, 0.78f) // #38BDF8
    private val bubbleLiquidBlue = floatArrayOf(0.05f, 0.65f, 0.91f, 0.95f) // #0EA5E9
    private val bubbleCoreBlue = floatArrayOf(0.01f, 0.52f, 0.78f, 1.0f)    // #0284C7

    // Walking state inside transparent overlay bounds
    private var walkX = 0f
    private var targetX = 0.35f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0f, 0f, 0f, 0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / height.coerceAtLeast(1)
        Matrix.perspectiveM(projMatrix, 0, 36f, aspect, 0.1f, 30f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        val t = (System.nanoTime() - startNs) / 1_000_000_000f
        Matrix.setLookAtM(viewMatrix, 0, 0f, 1.0f, 3.35f, 0f, 0.55f, 0f, 0f, 1f, 0f)

        // Wander smoothly across screen bounds while flexing 6 joints (scale = 0.62f small buddy)
        val dx = targetX - walkX
        if (abs(dx) < 0.03f) {
            targetX = sin(t * 0.41f) * 0.42f
        } else {
            walkX += dx * 0.02f
        }
        val legSwing = sin(t * 6.4f) * 0.58f
        val armSwing = -legSwing * 0.8f
        GestureEventBus.currentFrameState.set(walkX, legSwing, armSwing, bubbleOuterBlue, bubbleLiquidBlue, bubbleCoreBlue)
    }
}