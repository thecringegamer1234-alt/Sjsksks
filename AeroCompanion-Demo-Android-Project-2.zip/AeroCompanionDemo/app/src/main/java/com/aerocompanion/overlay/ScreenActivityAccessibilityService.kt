package com.aerocompanion.overlay

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ScreenActivityAccessibilityService : AccessibilityService() {
    private var lastPackage = ""
    private var packageStartMs = System.currentTimeMillis()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val pkg = ev.packageName?.toString() ?: return
        val now = System.currentTimeMillis()

        // React to real typing in ANY Android app text box
        if (ev.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            val typed = ev.text.joinToString(" ").trim()
            if (typed.length >= 4) {
                GestureEventBus.emitLiveTyping(pkg, typed)
            }
            return
        }

        if (pkg != lastPackage) {
            lastPackage = pkg
            packageStartMs = now
            GestureEventBus.emitScreenChanged(pkg)
        } else if (now - packageStartMs > 15 * 60 * 1000L) {
            packageStartMs = now
            GestureEventBus.emitLongDwellGesture(pkg)
        }
    }

    override fun onInterrupt() {}
}