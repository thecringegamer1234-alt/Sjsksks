package com.aerocompanion.overlay

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class CompanionNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val pkg = sbn?.packageName ?: return
        val extras = sbn.notification?.extras ?: return
        val title = extras.getString("android.title") ?: "Notification"
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        val gesture = when {
            pkg.contains("music") || pkg.contains("spotify") -> "vibe"
            pkg.contains("calendar") || pkg.contains("mail") -> "point"
            pkg.contains("health") || pkg.contains("water") -> "stretch_tip"
            else -> "notify_alert"
        }

        GestureEventBus.emitNotification(pkg, title, text, gesture)
    }
}