package com.aerocompanion.overlay

import android.content.Context
import androidx.room.*
import androidx.work.*

@Entity(tableName = "interaction_logs")
data class InteractionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientUid: String,
    val timestampIso: String,
    val screenPackage: String,
    val gesture: String,
    val speech: String,
    val syncStatus: String = "pending"
)

@Dao
interface InteractionDao {
    @Insert
    suspend fun insert(log: InteractionLogEntity)

    @Query("SELECT * FROM interaction_logs WHERE syncStatus = 'pending'")
    suspend fun getPending(): List<InteractionLogEntity>

    @Query("UPDATE interaction_logs SET syncStatus = 'synced' WHERE clientUid IN (:uids)")
    suspend fun markSynced(uids: List<String>)
}

@Database(entities = [InteractionLogEntity::class], version = 1)
abstract class CompanionDatabase : RoomDatabase() {
    abstract fun interactionDao(): InteractionDao
}

class CloudSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        // Triggered automatically by WorkManager when NetworkType.CONNECTED is satisfied
        return Result.success()
    }
}