package com.aerocompanion.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var glView: GLSurfaceView
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            360,
            420,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 48
            y = 220
        }

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            setZOrderOnTop(true)
            setRenderer(AeroOverlayRenderer(this@OverlayService))
            setOnTouchListener(createDragAndTapListener())
        }

        windowManager.addView(glView, params)
    }

    private fun createDragAndTapListener(): android.view.View.OnTouchListener {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        return android.view.View.OnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(glView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dist = kotlin.math.hypot(event.rawX - touchX, event.rawY - touchY)
                    if (dist < 14f) {
                        GestureEventBus.emitTouchReaction(event.x, event.y)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun startForegroundNotification() {
        val channelId = "aero_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AeroCompanion 3D Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Aqua Overlay Active")
            .setContentText("Floating 3D Frutiger Aero companion ready.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1001, notification)
    }

    override fun onDestroy() {
        if (::glView.isInitialized) {
            windowManager.removeView(glView)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}