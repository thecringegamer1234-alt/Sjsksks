#!/usr/bin/env bash
set -euo pipefail
# Run this inside the unzipped AeroCompanionDemo directory with Android SDK + JDK 17 installed:
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
echo "APK built at: app/build/outputs/apk/debug/app-debug.apk"