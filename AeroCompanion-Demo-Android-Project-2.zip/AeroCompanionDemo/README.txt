AeroCompanion Frutiger Aero 3D Android Overlay Demo Project
Open in Android Studio (Arctic Fox / Jellyfish+) and run ./gradlew assembleDebug to build the APK.
